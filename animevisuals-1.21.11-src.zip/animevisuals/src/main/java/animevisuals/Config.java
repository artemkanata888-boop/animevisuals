package animevisuals;

/** Переключатели модуля. Хранятся в памяти. */
public final class Config {
    public static boolean hud = true;
    public static boolean rings = true;
    public static boolean sky = true;
    public static boolean boost = false;

    private Config() {}
}
