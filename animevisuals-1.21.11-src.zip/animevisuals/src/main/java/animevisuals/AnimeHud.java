package animevisuals;

import java.awt.Color;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/** HUD, кружки при ударе и небесный фильтр. Только 2D-заливки, FPS не страдает. */
public final class AnimeHud implements HudElement {
    private static final List<Long> RINGS = new CopyOnWriteArrayList<>();
    private static final long RING_MS = 650;

    public static void addRing() {
        if (RINGS.size() < 6) RINGS.add(System.currentTimeMillis());
    }

    @Override
    public void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        try {
            int w = ctx.getScaledWindowWidth();
            int h = ctx.getScaledWindowHeight();
            if (Config.sky && mc.world != null) sky(ctx, mc, w, h);
            if (Config.rings) rings(ctx, w, h);
            if (Config.hud) panel(ctx, mc);
        } catch (Throwable ignored) {
            // HUD никогда не должен ронять клиент
        }
    }

    private static void sky(DrawContext ctx, MinecraftClient mc, int w, int h) {
        long t = mc.world.getTimeOfDay() % 24000L;
        int top;
        int bottom;
        if (t < 12000) {            // день
            top = 0x1E7FD0FF; bottom = 0x24FFC8E8;
        } else if (t < 14000) {     // закат
            top = 0x30FF7FB0; bottom = 0x38FFB070;
        } else if (t < 22500) {     // ночь
            top = 0x34301A7A; bottom = 0x3CB060D0;
        } else {                    // рассвет
            top = 0x2CFF9AC8; bottom = 0x32FFD890;
        }
        ctx.fillGradient(0, 0, w, h, top, bottom);
    }

    private static void rings(DrawContext ctx, int w, int h) {
        long now = System.currentTimeMillis();
        int cx = w / 2;
        int cy = h / 2;
        for (Long start : RINGS) {
            float a = (now - start) / (float) RING_MS;
            if (a >= 1f) { RINGS.remove(start); continue; }
            for (int k = 0; k < 2; k++) {
                float p = a - k * 0.18f;
                if (p <= 0f) continue;
                float r = 6f + p * 46f;
                int alpha = (int) ((1f - p) * 230f);
                int rgb = Color.HSBtoRGB(0.88f - p * 0.15f, 0.45f, 1f) & 0xFFFFFF;
                int color = (alpha << 24) | rgb;
                int n = Math.max(24, (int) (r * 1.6f));
                for (int i = 0; i < n; i++) {
                    double ang = (Math.PI * 2 * i) / n;
                    int x = cx + (int) Math.round(Math.cos(ang) * r);
                    int y = cy + (int) Math.round(Math.sin(ang) * r);
                    ctx.fill(x, y, x + 2, y + 2, color);
                }
            }
        }
    }

    private static void panel(DrawContext ctx, MinecraftClient mc) {
        long now = System.currentTimeMillis();
        float hue = (now % 6000L) / 6000f;
        int accent = 0xFF000000 | (Color.HSBtoRGB(hue, 0.45f, 1f) & 0xFFFFFF);
        int x = 6, y = 6, w = 108, h = 38;
        ctx.fill(x, y, x + w, y + h, 0x90140A24);
        ctx.fill(x, y, x + 3, y + h, accent);
        ctx.fill(x, y, x + w, y + 1, accent);
        String fps = "FPS " + mc.getCurrentFps();
        String xyz = String.format("X %d  Y %d  Z %d",
                (int) mc.player.getX(), (int) mc.player.getY(), (int) mc.player.getZ());
        ctx.drawText(mc.textRenderer, "Anime Visuals", x + 8, y + 5, accent, true);
        ctx.drawText(mc.textRenderer, fps, x + 8, y + 16, 0xFFFFE6F2, true);
        ctx.drawText(mc.textRenderer, xyz, x + 8, y + 26, 0xFFE0C8FF, true);
    }
}
