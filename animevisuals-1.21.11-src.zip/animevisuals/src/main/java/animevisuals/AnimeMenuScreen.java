package animevisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Меню в аниме-стиле: градиент и падающие лепестки сакуры. */
public class AnimeMenuScreen extends Screen {
    private static final int PW = 200;
    private static final int PH = 168;

    private ButtonWidget hudBtn, ringBtn, skyBtn, boostBtn;

    public AnimeMenuScreen() {
        super(Text.literal("Anime Visuals"));
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "§dВКЛ" : "§7ВЫКЛ"));
    }

    @Override
    protected void init() {
        int x = (this.width - 180) / 2;
        int y = (this.height - PH) / 2 + 28;

        hudBtn = ButtonWidget.builder(label("HUD", Config.hud), b -> {
            Config.hud = !Config.hud;
            b.setMessage(label("HUD", Config.hud));
        }).dimensions(x, y, 180, 20).build();

        ringBtn = ButtonWidget.builder(label("Кружки при ударе", Config.rings), b -> {
            Config.rings = !Config.rings;
            b.setMessage(label("Кружки при ударе", Config.rings));
        }).dimensions(x, y + 24, 180, 20).build();

        skyBtn = ButtonWidget.builder(label("Аниме-небо", Config.sky), b -> {
            Config.sky = !Config.sky;
            b.setMessage(label("Аниме-небо", Config.sky));
        }).dimensions(x, y + 48, 180, 20).build();

        boostBtn = ButtonWidget.builder(label("FPS Boost", Config.boost), b -> {
            Config.boost = !Config.boost;
            Boost.apply(Config.boost);
            b.setMessage(label("FPS Boost", Config.boost));
        }).dimensions(x, y + 72, 180, 20).build();

        addDrawableChild(hudBtn);
        addDrawableChild(ringBtn);
        addDrawableChild(skyBtn);
        addDrawableChild(boostBtn);
        addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close())
                .dimensions(x, y + 98, 180, 20).build());
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fillGradient(0, 0, this.width, this.height, 0xC0301A4D, 0xC0D95B9E);

        long t = System.currentTimeMillis();
        for (int i = 0; i < 26; i++) {
            float speed = 0.02f + (i % 3) * 0.012f;
            float y = ((t * speed) + i * 37f) % (this.height + 10) - 5;
            float x = (i * 53f + (float) Math.sin(t / 700.0 + i) * 14f) % this.width;
            int s = 2 + (i % 2);
            ctx.fill((int) x, (int) y, (int) x + s + 1, (int) y + s, 0xCCFFB7D5);
        }

        int px = (this.width - PW) / 2;
        int py = (this.height - PH) / 2;
        ctx.fill(px, py, px + PW, py + PH, 0xB0160A2A);
        ctx.fill(px, py, px + PW, py + 2, 0xFFFF8CC8);
        ctx.fill(px, py + PH - 2, px + PW, py + PH, 0xFFB48CFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("✿ Anime Visuals ✿"), this.width / 2, py + 10, 0xFFFFB7D5);
    }
}
