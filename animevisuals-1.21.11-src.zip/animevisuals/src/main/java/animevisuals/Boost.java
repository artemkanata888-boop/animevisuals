package animevisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.ParticlesMode;

/** Лёгкий FPS Boost: меньше частиц, облака и тени выкл, ближе сущности. */
public final class Boost {
    private static ParticlesMode oldParticles;
    private static CloudRenderMode oldClouds;
    private static Double oldEntityDist;
    private static Boolean oldShadows;

    private Boost() {}

    public static void apply(boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        try {
            if (on) {
                oldParticles = mc.options.getParticles().getValue();
                mc.options.getParticles().setValue(ParticlesMode.MINIMAL);
            } else if (oldParticles != null) {
                mc.options.getParticles().setValue(oldParticles);
            }
        } catch (Throwable ignored) {}
        try {
            if (on) {
                oldClouds = mc.options.getCloudRenderMode().getValue();
                mc.options.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            } else if (oldClouds != null) {
                mc.options.getCloudRenderMode().setValue(oldClouds);
            }
        } catch (Throwable ignored) {}
        try {
            if (on) {
                oldEntityDist = mc.options.getEntityDistanceScaling().getValue();
                mc.options.getEntityDistanceScaling().setValue(0.6);
            } else if (oldEntityDist != null) {
                mc.options.getEntityDistanceScaling().setValue(oldEntityDist);
            }
        } catch (Throwable ignored) {}
        try {
            if (on) {
                oldShadows = mc.options.getEntityShadows().getValue();
                mc.options.getEntityShadows().setValue(false);
            } else if (oldShadows != null) {
                mc.options.getEntityShadows().setValue(oldShadows);
            }
        } catch (Throwable ignored) {}
        try { mc.options.write(); } catch (Throwable ignored) {}
    }
}
